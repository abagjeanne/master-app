<?php

namespace App\Models;

interface ICompanyableChild
{
    public function getCompanyableParents();
}
