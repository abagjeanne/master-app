<?php
return array (
  'app_version' => 'v6.3.4',
  'full_app_version' => 'v6.3.4 - build 13139-g6f9ba6ede',
  'build_version' => '13139',
  'prerelease_version' => '',
  'hash_version' => 'g6f9ba6ede',
  'full_hash' => 'v6.3.4-234-g6f9ba6ede',
  'branch' => 'master',
);